import * as React from 'react'

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'default' | 'outline' | 'ghost'
  size?: 'default' | 'sm'
}

export function Button({
  className = '',
  variant = 'default',
  size = 'default',
  ...props
}: ButtonProps) {
  const variantClass =
    variant === 'outline'
      ? 'border border-[var(--color-hairline-gray)] bg-[var(--color-linen-white)] text-[var(--color-forest-ink)]'
      : variant === 'ghost'
        ? 'border border-transparent bg-transparent text-[var(--color-forest-ink)]'
        : 'border border-[var(--color-forest-ink)] bg-[var(--color-forest-ink)] text-[var(--color-linen-white)]'
  const sizeClass = size === 'sm' ? 'h-9 px-[11px] text-sm' : 'h-11 px-[21px] text-sm'

  return (
    <button
      className={`inline-flex items-center justify-center gap-[9px] rounded-[14px] font-normal transition-colors hover:bg-[var(--color-linen)] hover:text-[var(--color-forest-ink)] disabled:cursor-not-allowed disabled:opacity-50 ${variantClass} ${sizeClass} ${className}`}
      {...props}
    />
  )
}
