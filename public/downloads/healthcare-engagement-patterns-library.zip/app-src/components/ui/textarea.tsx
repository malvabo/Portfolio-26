import * as React from 'react'

export function Textarea({ className = '', ...props }: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={`w-full rounded-[14px] border border-[var(--color-hairline-gray)] bg-[var(--color-linen-white)] p-[14px] text-sm leading-[1.5] text-[var(--color-charcoal)] outline-none focus:border-[var(--color-forest-ink)] ${className}`}
      {...props}
    />
  )
}
