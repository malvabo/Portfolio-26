import * as React from 'react'

export function Label({ className = '', ...props }: React.LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label
      className={`mb-[7px] block text-sm font-normal text-[var(--color-forest-ink)] ${className}`}
      {...props}
    />
  )
}
