import * as React from 'react'

export function Input({ className = '', ...props }: React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={`h-11 w-full rounded-[14px] border border-[var(--color-hairline-gray)] bg-[var(--color-linen-white)] px-[14px] text-sm text-[var(--color-charcoal)] outline-none focus:border-[var(--color-forest-ink)] ${className}`}
      {...props}
    />
  )
}
