export interface Pattern {
  id: string
  title: string
  subtitle: string
  description: string
  category: string
  overview: string
  overviewImageUrl: string
  overviewImageAlt: string
  whyItWorks: Array<{
    title: string
    description: string
  }>
  whyItWorksImageUrl: string
  whyItWorksImageAlt: string
  considerations: Array<{
    title: string
    description: string
  }>
  learnMoreLink: string
  additionalImages: Array<{
    url: string
    alt: string
  }>
}

