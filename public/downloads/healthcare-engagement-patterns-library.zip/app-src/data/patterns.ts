import { patterns, Pattern } from './patternData'

const userPatterns: Pattern[] = []

export function getPatternById(id: string): Pattern | undefined {
  return [...patterns, ...userPatterns].find(pattern => pattern.id === id)
}

export function getAllPatterns(): Pattern[] {
  return [...patterns, ...userPatterns]
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

export function addUserPattern(pattern: Omit<Pattern, 'id'>): Pattern {
  const newPattern: Pattern = {
    ...pattern,
    id: `${slugify(pattern.title || 'pattern')}-${Date.now()}`,
    additionalImages: pattern.additionalImages || [],
  }

  userPatterns.push(newPattern)
  return newPattern
}

export function updateUserPattern(id: string, updates: Partial<Pattern>): Pattern | undefined {
  const index = userPatterns.findIndex(pattern => pattern.id === id)
  if (index === -1) return undefined

  userPatterns[index] = { ...userPatterns[index], ...updates }
  return userPatterns[index]
}

export function deleteUserPattern(id: string): boolean {
  const index = userPatterns.findIndex(pattern => pattern.id === id)
  if (index === -1) return false

  userPatterns.splice(index, 1)
  return true
}
