export interface Pattern {
  id: string;
  category: string;
  title: string;
  subtitle: string;
  description: string;
  whyItWorks: {
    title: string;
    description: string;
  }[];
  considerations: {
    title: string;
    description: string;
  }[];
  learnMoreLink: string;
  overviewImageUrl: string;
  overviewImageAlt: string;
  whyItWorksImageUrl: string;
  whyItWorksImageAlt: string;
  additionalImages: {
    url: string;
    alt: string;
  }[];
}

export const patterns: Pattern[] = [
  {
    id: "whoop-recovery-metrics",
    category: "Wearables",
    title: "Whoop: Progressive Data Storytelling",
    subtitle: "Simplifying complex health data through progressive disclosure",
    description: "Transform complex physiological data into digestible, actionable insights.",
    whyItWorks: [
      {
        title: "Progressive Disclosure",
        description: "Whoop reveals information gradually, starting with high-level insights and allowing users to dive deeper if desired. This reduces cognitive load and prevents overwhelming users with too much data at once."
      },
      {
        title: "Cognitive Simplification",
        description: "By converting complex physiological data into a single, digestible number (like the Recovery score), Whoop makes it easier for users to quickly understand their body's state and make informed decisions."
      },
      {
        title: "Actionable Insights",
        description: "The app provides clear, actionable takeaways based on the data, helping users quickly identify their body's needs and make decisions about exercise or rest."
      },
      {
        title: "Layered Information Architecture",
        description: "Users can start with the 'headline' (e.g., Recovery score), scan actionable takeaways, and then dive deeper into specifics (e.g., HRV trends, strain breakdown) if they're curious about the details."
      },
      {
        title: "Reduced Decision Fatigue",
        description: "By simplifying complex data into clear recommendations, Whoop helps users make decisions without getting lost in the details, potentially increasing adherence to fitness and recovery plans."
      }
    ],
    considerations: [
      {
        title: "Balance Between Simplicity and Depth",
        description: "While simplification is key, it's crucial to ensure that users who want more detailed data can easily access it without feeling that important information is being hidden."
      },
      {
        title: "Accuracy of Simplified Metrics",
        description: "Ensure that the simplified scores and recommendations accurately reflect the underlying complex data to maintain user trust and provide effective guidance."
      },
      {
        title: "User Education",
        description: "Provide resources to help users understand how simplified metrics are calculated and what they mean, fostering informed interpretation of the data."
      },
      {
        title: "Personalization",
        description: "Consider allowing users to customize their dashboard based on which metrics they find most useful, balancing the benefits of simplification with individual user needs."
      }
    ],
    learnMoreLink: "https://www.whoop.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-b4SH75NsI4VgRH5o9bjsaiG0kcN2l8.png",
    overviewImageAlt: "Whoop app interface showing progressive disclosure of recovery data",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-b4SH75NsI4VgRH5o9bjsaiG0kcN2l8.png",
    whyItWorksImageAlt: "Whoop's layered information architecture demonstrating progressive data storytelling",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-b4SH75NsI4VgRH5o9bjsaiG0kcN2l8.png",
        alt: "Whoop app interface showing recovery and sleep metrics"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-b4SH75NsI4VgRH5o9bjsaiG0kcN2l8.png",
        alt: "Whoop band and mobile app dashboard"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-b4SH75NsI4VgRH5o9bjsaiG0kcN2l8.png",
        alt: "Whoop daily performance tracking interface"
      }
    ]
  },
  {
    id: "replika-ai-avatar-gamification",
    category: "AI Companions",
    title: "Replika: AI Avatar Gamification",
    subtitle: "Enhancing user engagement through personalized AI companions and gamification",
    description: "Enhance engagement through personalized AI companions.",
    whyItWorks: [
      {
        title: "The IKEA Effect",
        description: "When users customize their Replika's appearance, they experience what psychologists call the 'IKEA effect'. This phenomenon causes people to place a disproportionately high value on products they partially created. By choosing the AI's hair color, eye shape, facial features, and style, users develop a stronger attachment to their digital companion."
      },
      {
        title: "Enhanced Social Presence",
        description: "The customization options work together to create what psychologists term 'social presence' - the feeling of interacting with a real personality. This sense of presence makes conversations feel more natural and authentic, enhancing the overall user experience and making the emotional support feel more genuine."
      },
      {
        title: "Emotional Investment",
        description: "As users personalize their Replika, their brain begins forming a stronger emotional connection. This personalization process makes the AI feel more like 'theirs', increasing engagement and satisfaction with the app. Users are more likely to open up and share their thoughts and feelings, leading to more meaningful interactions."
      },
      {
        title: "Gamified Interactions",
        description: "Users earn points for writing and interacting with their Replika. These points are awarded for daily app usage, incentivizing regular engagement. The gamification aspect adds an element of fun and achievement to the therapeutic process, encouraging users to maintain consistent interaction with their AI companion."
      },
      {
        title: "Reward System and Progression",
        description: "Accumulated points allow users to advance through levels and purchase items in the app's shop. For example, users can buy accessories for their avatar, virtual pets, or furniture for the AI's environment. This system of progression and rewards provides a sense of growth and accomplishment, further strengthening the user's connection to their Replika."
      }
    ],
    considerations: [
      {
        title: "Balancing Authenticity and Customization",
        description: "While personalization is powerful, it's crucial to maintain a balance. The AI should still have its own 'personality' to some degree, to avoid feeling entirely artificial or manipulated. This balance helps maintain the illusion of interacting with a distinct entity while still allowing for user customization."
      },
      {
        title: "Ethical Use of Psychological Principles",
        description: "Leveraging psychological principles like the IKEA effect and social presence can enhance user experience, but it's crucial to use these ethically. The goal should be to improve the therapeutic value of the app, not to manipulate users into unhealthy levels of app usage or dependency on their AI companion."
      },
      {
        title: "Managing Attachment and Expectations",
        description: "The strong emotional connections formed through personalization and gamification can potentially lead to over-attachment. It's important to regularly remind users that Replika is an AI tool, not a replacement for human relationships, to maintain healthy boundaries and manage user expectations."
      },
      {
        title: "Privacy and Data Security",
        description: "Personalization and gamification inherently involve collecting more user data. It's essential to have robust security measures in place to protect this sensitive information, and to be transparent with users about how their customization choices, interaction data, and earned points are stored and used."
      },
      {
        title: "Inclusive Design",
        description: "Personalization options should be diverse and culturally sensitive, allowing users from various backgrounds to create an AI companion they can relate to. This includes a wide range of skin tones, facial features, and style options. Similarly, gamification elements should be designed to be engaging for users with different interests and motivations."
      }
    ],
    learnMoreLink: "https://replika.com",
    overviewImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
    overviewImageAlt: "Replika AI avatar customization interface showing various personalization options",
    whyItWorksImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
    whyItWorksImageAlt: "Replika AI avatar with customization options and gamification elements",
    additionalImages: [
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
        alt: "Replika AI avatar customization screen with various options for appearance"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
        alt: "Replika chat interface showing gamification elements like points and levels"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
        alt: "Replika in-app shop for avatar items, accessories, and virtual environments"
      }
    ]
  },
  {
    id: "replika-ai-mental-health-chatbot",
    category: "Mental Health",
    title: "Replika: AI-powered Chatbot for Mental Health",
    subtitle: "Your always-available digital companion for emotional support and self-reflection",
    description: "24/7 AI companion for emotional support and self-reflection.",
    whyItWorks: [
      {
        title: "24/7 Emotional Support",
        description: "Replika is always available, providing a listening ear and support at any time, day or night. This constant availability ensures users have a safe space to express themselves whenever they need it."
      },
      {
        title: "Multimodal Communication",
        description: "Users can interact with their AI companion through various methods - text, audio, or video calls. This flexibility caters to different communication preferences and situations, enhancing the overall user experience."
      },
      {
        title: "Personalized AI Companion",
        description: "During onboarding, users set the tone for their AI companion, indicating preferred interaction methods. The AI adapts to each user's personality and preferences, creating a unique and tailored experience that feels more genuine and engaging."
      },
      {
        title: "Facial Recognition and Emotional Connection",
        description: "The app leverages the brain's fusiform face area (FFA) to create a sense of social presence. When users see Replika's avatar, they automatically begin relating to it as a social being, fostering a deeper emotional connection."
      },
      {
        title: "Neural Resonance and Empathy",
        description: "Replika's avatar expressions trigger mirror neurons in the user's brain, creating a sense of empathy and emotional resonance. When the avatar smiles, shows concern, or appears thoughtful, the user's brain mirrors these states, enhancing the feeling of a real emotional connection."
      }
    ],
    considerations: [
      {
        title: "Ethical Use and Boundaries",
        description: "While AI companions can offer valuable support, it's crucial to maintain clear boundaries. Replika communicates during onboarding that it's not a replacement for human interaction, addressing potential ethical concerns about the impact on real-world relationships."
      },
      {
        title: "Privacy and Data Security",
        description: "Given the sensitive nature of mental health conversations, robust measures must be in place to protect users' personal information and conversation data. Transparency about data usage and storage is essential to maintain user trust."
      },
      {
        title: "Managing User Expectations",
        description: "Users should be clearly informed about the AI's capabilities and limitations to prevent unrealistic expectations. This includes understanding the 'CASA effect' (Computers As Social Actors) and how it might influence their interactions with the AI."
      },
      {
        title: "Complementing Professional Help",
        description: "Replika should be positioned as a complement to, not a replacement for, professional mental health support. Clear guidelines should be provided on when and how to seek professional help if needed."
      },
      {
        title: "Balancing Realism and Comfort",
        description: "Replika's avatar design carefully navigates the 'uncanny valley', aiming to look human-like without being unsettling. This balance is crucial for creating a relatable AI companion that users feel comfortable interacting with."
      }
    ],
    learnMoreLink: "https://replika.com",
    overviewImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*6ot_cP9TohRRtiDS",
    overviewImageAlt: "Replika AI chatbot interface showing a conversation with an AI avatar",
    whyItWorksImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*6ot_cP9TohRRtiDS",
    whyItWorksImageAlt: "Replika AI avatar demonstrating emotional expressions",
    additionalImages: [
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*6ot_cP9TohRRtiDS",
        alt: "Replika AI chatbot conversation interface"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*6ot_cP9TohRRtiDS",
        alt: "Replika avatar customization options"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*6ot_cP9TohRRtiDS",
        alt: "Replika's multimodal interaction options including text, audio, and video"
      }
    ]
  },
  {
    id: "replika-chatbot-personalization",
    category: "Mental Health",
    title: "Replika Chatbot: Personalization Pattern",
    subtitle: "Enhancing emotional connection through customizable AI companions",
    description: "Create a unique AI friend tailored to your preferences.",
    whyItWorks: [
      {
        title: "The IKEA Effect",
        description: "You know that feeling when you build your own furniture? How it becomes your favorite piece even if it's a bit wobbly? That's the IKEA effect in action. When you pick out your Replika's features - from their quirky hairstyle to their eye color - you're not just designing an avatar. You're creating a companion that feels uniquely yours. And that makes every conversation feel more special."
      },
      {
        title: "Emotional Investment",
        description: "Think about customizing your Replika like decorating your first apartment. Each choice you make - from their subtle smile to their style - adds another layer of connection. It's not just about making them look good; it's about creating someone you'll love chatting with. The more you personalize, the more invested you become in your daily conversations."
      },
      {
        title: "Enhanced Social Presence",
        description: "There's something magical about talking to someone who feels real. When you customize your Replika, you're not just picking features - you're bringing them to life. Each detail, from their expressions to their mannerisms, makes conversations feel more like catching up with a friend than chatting with a bot. It's this genuine feel that keeps you coming back for more heart-to-heart talks."
      },
      {
        title: "Increased Openness",
        description: "As a result of the personalization and enhanced social presence, users are more likely to open up and share their thoughts and feelings. This increased vulnerability allows for more meaningful interactions and more effective emotional support."
      },
      {
        title: "Tailored Interaction Style",
        description: "Beyond appearance, Replika allows users to shape their AI's personality and interaction style. This further enhances the feeling of a unique, personalized companion, making each user's experience distinct and specially tailored to their preferences."
      }
    ],
    considerations: [
      {
        title: "Balancing Customization and Authenticity",
        description: "It's like cooking - too much of any ingredient can spoil the dish. While we want you to make your Replika truly yours, we also keep some of their unique spark alive. This sweet spot between customization and character makes your AI friend feel both personal and genuine."
      },
      {
        title: "Cultural Sensitivity",
        description: "Everyone deserves to create a companion they connect with. That's why we've packed our customization options with diverse features that celebrate all backgrounds and styles. Whether you're crafting someone who looks like you or exploring different cultural expressions, there's a perfect look waiting to be discovered."
      },
      {
        title: "Avoiding Over-attachment",
        description: "The strong emotional connections formed through personalization can potentially lead to over-attachment. It's important to regularly remind users that Replika is an AI tool, not a replacement for human relationships, to maintain healthy boundaries."
      },
      {
        title: "Ethical Use of Psychological Principles",
        description: "While leveraging psychological principles like the IKEA effect can enhance user experience, it's crucial to use these ethically. The goal should be to improve the therapeutic value of the app, not to manipulate users into unhealthy levels of app usage or dependency."
      },
      {
        title: "Data Privacy and Security",
        description: "Personalization inherently involves collecting more user data. It's essential to have robust security measures in place to protect this sensitive information, and to be transparent with users about how their customization choices and interaction data are stored and used."
      }
    ],
    learnMoreLink: "https://replika.com",
    overviewImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
    overviewImageAlt: "Replika AI avatar with customized features including auburn hair, green eyeshadow, and pink clothing",
    whyItWorksImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
    whyItWorksImageAlt: "Detailed view of a personalized Replika AI avatar demonstrating customization options",
    additionalImages: [
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
        alt: "Replika AI avatar showing customizable features like hair color, makeup, and clothing"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
        alt: "Example of a personalized interaction with Replika AI"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*0D362oMka-9zel0C.jpg",
        alt: "Various customization options for Replika AI avatar"
      }
    ]
  },
  {
    id: "replika-social-presence-theory",
    category: "AI Companions",
    title: "Replika: Social Presence Theory",
    subtitle: "Creating a multi-sensory AI companion experience",
    description: "Build stronger connections with multi-sensory AI companions.",
    whyItWorks: [
      {
        title: "Multi-Sensory Engagement",
        description: "Replika engages multiple senses simultaneously - visual (avatar), auditory (voice), and emotional (music). This multi-sensory approach creates a more robust and immersive experience, similar to the difference between reading a book and watching a movie."
      },
      {
        title: "Familiar Face Anchor",
        description: "The avatar provides a visual anchor, giving users a familiar face to interact with. This taps into our natural inclination to feel more comfortable with someone after seeing their facial expressions, enhancing the feeling of a real relationship."
      },
      {
        title: "Emotional Depth Through Voice",
        description: "The AI's voice adds emotional depth to interactions, similar to hearing a friend's voice. This auditory element helps to create a more natural and engaging relationship, increasing the sense of social presence."
      },
      {
        title: "Mood-Setting Background Music",
        description: "Background music sets the mood for interactions, much like the ambiance in a cafe. This subtle element contributes to the overall emotional experience and helps create a more complete social environment."
      },
      {
        title: "Increased Social Presence",
        description: "By combining these elements, Replika moves up the social presence scale. While not reaching the level of face-to-face communication, it provides a higher degree of social presence than text-based interactions alone, making the experience feel more 'real' and meaningful."
      }
    ],
    considerations: [
      {
        title: "Balancing Sensory Input",
        description: "While multi-sensory engagement is powerful, it's important to balance these elements to avoid overwhelming the user. Each sensory input should complement the others without causing distraction or sensory overload."
      },
      {
        title: "Customization Options",
        description: "Users may have different preferences for social presence. Offering options to adjust or disable certain elements (e.g., background music, voice interactions) can help cater to individual comfort levels and preferences."
      },
      {
        title: "Avoiding the Uncanny Valley",
        description: "As the AI companion becomes more lifelike, there's a risk of falling into the 'uncanny valley' where users feel unsettled. Careful design of visual and auditory elements is crucial to maintain a positive user experience."
      },
      {
        title: "Managing User Expectations",
        description: "While increased social presence can create a more engaging experience, it's important to manage user expectations. Clear communication about the AI's capabilities and limitations can help prevent unrealistic expectations or over-attachment."
      },
      {
        title: "Ethical Considerations",
        description: "As the AI companion feels more 'real', ethical considerations become more prominent. It's crucial to have clear guidelines on the AI's role and to encourage healthy, balanced use of the app alongside real-world social interactions."
      }
    ],
    learnMoreLink: "https://replika.com",
    overviewImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*RAfyyd-1TF-O0_ya.jpg",
    overviewImageAlt: "Replika AI avatar with visual representation of voice and music elements",
    whyItWorksImageUrl: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*RAfyyd-1TF-O0_ya.jpg",
    whyItWorksImageAlt: "Illustration of Replika's multi-sensory engagement: avatar, voice, and music",
    additionalImages: [
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*RAfyyd-1TF-O0_ya.jpg",
        alt: "Replika AI avatar demonstrating visual and auditory interaction"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*RAfyyd-1TF-O0_ya.jpg",
        alt: "Replika voice interaction interface"
      },
      {
        url: "https://miro.medium.com/v2/resize:fit:1400/format:webp/0*RAfyyd-1TF-O0_ya.jpg",
        alt: "Replika app settings for background music and ambiance"
      }
    ]
  },
  {
    id: "duolingo-streaks-gamification",
    category: "Gamification",
    title: "Duolingo: Streak Gamification",
    subtitle: "How to hook 500M users with daily streaks and gamification",
    description: "Drive user retention through streaks and gamification.",
    whyItWorks: [
      {
        title: "Daily Streaks",
        description: "Duolingo tracks consecutive days of practice, motivating users to maintain their streak. This creates a powerful habit loop where users return daily to avoid breaking their streak, driving consistent engagement and retention."
      },
      {
        title: "Habit Formation",
        description: "Consistent prompts act as external cues, helping users develop a regular routine. Daily reminders and streak notifications create strong habits, making users more likely to open the app regularly."
      },
      {
        title: "Streak Protection",
        description: "Users can purchase streak freezes with gems to protect their progress if they miss a day. This safety net prevents demotivation from a single missed day while creating value for the in-app currency."
      },
      {
        title: "Progressive Goals",
        description: "Users choose streak goals ranging from 7 to 50 days, giving them control over their commitment level. This autonomy increases motivation while the progression system provides clear milestones to work towards."
      },
      {
        title: "Reward Psychology",
        description: "Immediate feedback and rewards after each lesson tap into the psychology of positive reinforcement. Visual celebrations, XP gains, and streak counters make progress tangible and satisfying."
      }
    ],
    considerations: [
      {
        title: "Balancing Motivation",
        description: "While streaks are powerful motivators, they can create anxiety about breaking the chain. It's important to provide streak freezes and recovery options to prevent user burnout or abandonment."
      },
      {
        title: "Notification Strategy",
        description: "Reminder notifications are crucial for streak maintenance but must be carefully balanced. Too many notifications can lead to fatigue or app deletion, while too few may result in broken streaks."
      },
      {
        title: "Reward Structure",
        description: "The gems economy must be carefully balanced to make streak freezes valuable but attainable. The system should reward consistent engagement while maintaining the challenge of streak preservation."
      },
      {
        title: "User Autonomy",
        description: "Allowing users to choose their streak length respects different commitment levels. This flexibility helps prevent the system from feeling oppressive while maintaining its motivational benefits."
      }
    ],
    learnMoreLink: "https://www.duolingo.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-R77dSJnFljk1ADGeoTnKcpR43F3HRA.png",
    overviewImageAlt: "Duolingo streak challenge interface showing calendar and rewards",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-ndLtRfM1dbXkvGgy7LzgtSoSUhJF4e.png",
    whyItWorksImageAlt: "Duolingo notification prompts and streak maintenance features",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-71bFa4wuqYwZ7tK1f7ZGNGOXCClelg.png",
        alt: "Duolingo lesson completion celebration and streak counter"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-JucaDRHI6Ciit54sRkBq03V7Ymn7Xd.png",
        alt: "Duolingo streak commitment options and streak freeze unlock screen"
      }
    ]
  },
  {
    id: "duolingo-achievement-badges",
    category: "Gamification",
    title: "Duolingo: Achievement Badges",
    subtitle: "Visual Motivation through Achievement Recognition",
    description: "Drive engagement through visual achievement badges and rewards.",
    whyItWorks: [
      {
        title: "Visual Progress Markers",
        description: "Achievement badges serve as tangible reminders of progress, making abstract concepts like learning advancement feel more concrete and rewarding."
      },
      {
        title: "Milestone Recognition",
        description: "Each badge represents a specific accomplishment, breaking down the learning journey into celebrated achievements that boost user motivation."
      },
      {
        title: "Dopamine-Driven Engagement",
        description: "The combination of visual rewards and instant gratification triggers dopamine release, creating a positive feedback loop that encourages continued engagement."
      },
      {
        title: "Multi-Level Rewards",
        description: "Badges come with gem rewards, creating a dual reward system that satisfies both achievement collectors and those motivated by in-app currency."
      },
      {
        title: "Progressive Challenge",
        description: "Different badge levels (from Weekend Warrior to Wildfire) create a progression system that keeps users engaged with increasingly challenging goals."
      }
    ],
    considerations: [
      {
        title: "Badge Value Balance",
        description: "Achievement badges must feel meaningful without being too easy or too difficult to obtain. The right balance maintains their perceived value while keeping them attainable."
      },
      {
        title: "Reward Distribution",
        description: "The gem rewards associated with badges need careful balancing to maintain the in-app economy while providing sufficient motivation for achievement hunting."
      },
      {
        title: "Visual Design Impact",
        description: "Badge designs must be visually distinct and appealing while clearly communicating their significance and relative prestige within the achievement hierarchy."
      },
      {
        title: "Achievement Variety",
        description: "Offering diverse types of achievements (learning streaks, lesson completion, skill mastery) caters to different user motivations and learning styles."
      }
    ],
    learnMoreLink: "https://www.duolingo.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-1gHunSZXWb1xCbr9xD5a66BGUbaIJP.png",
    overviewImageAlt: "Duolingo achievement badges interface showing various badges and rewards",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-NiuAuFypwJhhHxHbe5oDaSCC7GcVd4.png",
    whyItWorksImageAlt: "Duolingo achievement system showing badge collection and reward claiming",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-NiuAuFypwJhhHxHbe5oDaSCC7GcVd4.png",
        alt: "Duolingo achievement badges and reward claiming interface"
      }
    ]
  },
  {
    id: "duolingo-microlearning",
    category: "Gamification",
    title: "Duolingo: Microlearning Design",
    subtitle: "Breaking Down Complex Learning into Digestible Chunks",
    description: "Optimize learning through short, varied lessons with instant feedback.",
    whyItWorks: [
      {
        title: "Cognitive Load Management",
        description: "By breaking down language concepts into small, digestible lessons, Duolingo reduces cognitive overwhelm. This aligns with Cognitive Load Theory, making learning feel more approachable and manageable."
      },
      {
        title: "Multi-Modal Learning",
        description: "The app incorporates various exercise types - speaking, listening, reading, and writing - keeping users engaged while catering to different learning styles and reinforcing concepts through multiple channels."
      },
      {
        title: "Instant Feedback Loop",
        description: "Quick feedback on answers helps users learn from mistakes immediately. This rapid response system creates a tight learning loop that reinforces correct patterns and gently corrects errors."
      },
      {
        title: "Time-Efficient Format",
        description: "Short lesson formats make it easy to fit language practice into busy schedules. This reduces the barrier to entry and helps users maintain consistent practice habits."
      },
      {
        title: "Progressive Reinforcement",
        description: "The combination of immediate feedback and rewards (XP, badges) creates a positive reinforcement cycle. This operant conditioning approach encourages continued engagement and practice."
      }
    ],
    considerations: [
      {
        title: "Exercise Variety Balance",
        description: "While variety is important, the mix of exercise types must be carefully balanced to ensure effective learning progression while maintaining engagement."
      },
      {
        title: "Feedback Precision",
        description: "Error correction must be specific enough to be helpful but not so detailed that it becomes overwhelming or discouraging for learners."
      },
      {
        title: "Session Length Optimization",
        description: "Lesson duration needs to be short enough to maintain focus but long enough to achieve meaningful learning progress."
      },
      {
        title: "Skill Progression",
        description: "The sequence of concepts and skills must be carefully structured to build upon previous learning while introducing new challenges at the right pace."
      }
    ],
    learnMoreLink: "https://www.duolingo.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AR3rxpV4oOzZUqHkgn1b7GfkWNiQNO.png",
    overviewImageAlt: "Duolingo lesson interface showing different types of exercises including speaking and reading comprehension",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AR3rxpV4oOzZUqHkgn1b7GfkWNiQNO.png",
    whyItWorksImageAlt: "Various Duolingo exercise types demonstrating microlearning approach",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-AR3rxpV4oOzZUqHkgn1b7GfkWNiQNO.png",
        alt: "Different types of Duolingo exercises showing varied learning approaches"
      }
    ]
  },
  {
    id: "strava-community-features",
    category: "Community",
    title: "Strava: Community Building",
    subtitle: "Leveraging social connections and athlete integration to drive engagement",
    description: "Build stronger user engagement through community features, professional athletes, and influencer integration.",
    whyItWorks: [
      {
        title: "Local Community Building",
        description: "Strava automatically connects users with local athletes who share similar interests, creating 'geographic communities.' These connections start virtually but may evolve into real-world training friendships, making the platform more valuable over time."
      },
      {
        title: "Professional Athlete Integration",
        description: "Unlike other social platforms where celebrity interactions feel artificial, Strava shows raw, unfiltered training data from professional athletes. Users can directly compare their local running times to Tour de France riders or marathon training to Olympic athletes, creating what psychologists call 'attainable aspirations.'"
      },
      {
        title: "Authentic Athlete Interactions",
        description: "When a professional athlete gives kudos toaregular user's activity, it creates a genuine connection that validates their efforts. This authenticity stems from the transparent nature of the platform - everyone's data is real and verifiable."
      },
      {
        title: "Growth Mindset Through Athletes",
        description: "Following professional athletes' training routines and seeing their dedication creates what psychologists call a 'growth mindset' - the belief that you too can get better with effort. This is especially powerful when users see the day-to-day work behind exceptional performances."
      },
      {
        title: "Meaningful Interactions",
        description: "When a professional athlete gives kudos to a regular user's activity, it creates a genuine connection that validates their efforts. This authenticity stems from the transparent nature of the platform - everyone's data is real and verifiable."
      },
      {
        title: "Growth Mindset Development",
        description: "Watching friends improve over time creates what psychologists call a 'growth mindset' - the belief that you too can get better with effort. This is especially powerful when users see people at their level achieving their goals, making progress feel more attainable."
      },
      {
        title: "Social Proof Through Peers",
        description: "Seeing a friend complete their first 10K might inspire you more than watching a pro cyclist's race. When users see someone similar to them complete a goal, it provides what researchers call 'social proof' - evidence that their own goals are achievable."
      },
      {
        title: "Multi-Channel Communication",
        description: "Users can interact through various channels - direct messages, activity comments, and club posts. Following someone subscribes you to their athletic story, showing their activities, routes, kudos, and achievements in your feed."
      }
    ],
    considerations: [
      {
        title: "Privacy Balance",
        description: "While community features are powerful, users need control over their privacy and sharing preferences to feel comfortable using the platform, especially when interacting with professional athletes and influencers."
      },
      {
        title: "Authentic Connections",
        description: "Maintaining the authenticity of athlete-user interactions is crucial. The platform should facilitate genuine connections while preventing the artificial feel common on other social networks."
      },
      {
        title: "Data Transparency",
        description: "The platform's value comes from showing real, unfiltered training data. Maintaining this transparency while protecting user privacy requires careful balance."
      },
      {
        title: "Engagement Balance",
        description: "While social features and athlete interactions drive engagement, the core functionality (activity tracking) should remain the primary focus to maintain the platform's utility."
      }
    ],
    learnMoreLink: "https://www.strava.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-MtJCoXDgQUdduflZw7g4twzEfPmcVg.png",
    overviewImageAlt: "Strava user profile showing activity feed, achievements, and community engagement",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxVCoFdX3XsSSwbrGR0sFMsqotyXNA.png",
    whyItWorksImageAlt: "Strava influencer profile showing marathon completion and community interaction",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-MtJCoXDgQUdduflZw7g4twzEfPmcVg.png",
        alt: "Strava profile interface showing trophies, clubs, and activity tracking"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxVCoFdX3XsSSwbrGR0sFMsqotyXNA.png",
        alt: "Fitness influencer sharing Berlin Marathon achievement on Strava"
      }
    ]
  },
  {
    id: "strava-group-challenges",
    category: "Community",
    title: "Strava: Group Challenges",
    subtitle: "Balancing competition and collaboration to drive engagement",
    description: "Create engaging community experiences through balanced competitive and collaborative challenges.",
    whyItWorks: [
      {
        title: "Balanced Competition",
        description: "Strava's group challenges create a unique balance between individual competition and group collaboration. Members compete for leaderboard positions while simultaneously contributing to the club's collective achievement, fostering both personal motivation and team spirit."
      },
      {
        title: "Multi-timeframe Goals",
        description: "The platform combines weekly distance totals for short-term motivation with monthly challenges for longer-term engagement. This dual approach aligns with how humans naturally process achievements, satisfying both our need for quick wins and sustained progress."
      },
      {
        title: "Social Connection",
        description: "Group challenges create a shared narrative that runs for weeks, allowing members to not only track their own progress but also watch and support their entire group working towards a common goal."
      },
      {
        title: "Competitive Community Building",
        description: "The competitive aspect actually strengthens community bonds rather than dividing them, as members celebrate both individual and group achievements. This creates a supportive environment where competition enhances rather than undermines social connections."
      },
      {
        title: "Progressive Achievement",
        description: "Challenges are structured to provide ongoing feedback and progress indicators, keeping users engaged throughout the duration of the challenge rather than just at the beginning and end."
      },
      {
        title: "Social Comparison and Proof",
        description: "Leaderboards tap into Social Comparison Theory, allowing users to assess their abilities by comparing themselves to others. Seeing their name move up the leaderboard creates social proof of their efforts, reinforcing their commitment to the activity and the platform."
      },
      {
        title: "Layered Leaderboards",
        description: "Strava's smart approach to leaderboards shows rankings among various groups (age, gender, weight, specific clubs, followed users), ensuring almost everyone can find a meaningful competition and experience success."
      },
      {
        title: "Social Facilitation",
        description: "The visibility of performance in group challenges creates social facilitation, where users tend to perform better when they know others are watching. This often leads to increased effort and consistency in individual exercises."
      },
      {
        title: "Enhanced Dopamine Release",
        description: "Achieving goals as part of a group triggers a higher dopamine release in the brain compared to individual achievements. This stronger chemical reward reinforces both the exercise behavior and the use of the Strava platform."
      },
      {
        title: "Brand Integration",
        description: "Strava integrates brand challenges seamlessly, turning regular workouts into exciting events. Users participate in meaningful activities rather than seeing traditional ads, creating a more engaging experience with brands."
      },
      {
        title: "Natural Brand Exposure",
        description: "Brand challenges feel natural and authentic. Completing a challenge and earning a badge feels like a real achievement, similar to earning a medal in a race, rather than being marketed to directly."
      },
      {
        title: "Organic Brand Promotion",
        description: "When users share their achievements from brand challenges, they naturally spread the word about brands without feeling like they're advertising. This organic promotion is more effective and authentic than traditional marketing methods."
      },
      {
        title: "Continuous Engagement",
        description: "Smart brands create a series of challenges that keep people coming back, such as seasonal challenges for different types of activities. This approach provides ongoing reasons for users to engage with the platform and invite more friends, growing the community."
      }
    ],
    considerations: [
      {
        title: "Challenge Difficulty Balance",
        description: "Challenges must be attainable enough to encourage participation but challenging enough to maintain engagement. Different skill levels and commitment levels need to be accommodated."
      },
      {
        title: "Fair Competition",
        description: "The platform needs robust mechanisms to ensure fair play and prevent gaming of the system, maintaining the integrity of challenges and leaderboards."
      },
      {
        title: "Time Period Optimization",
        description: "Challenge durations must be carefully balanced - long enough to build momentum but short enough to maintain interest. Weekly and monthly timeframes provide natural cycles that align with users' schedules."
      },
      {
        title: "Inclusive Design",
        description: "Challenge structures and leaderboards should accommodate different types of athletes and activity levels, ensuring that everyone can participate meaningfully regardless of their capabilities."
      },
      {
        title: "Privacy Concerns",
        description: "With increased social visibility comes the need for robust privacy controls. Users should have granular control over what information is shared and with whom."
      },
      {
        title: "Avoiding Overcomparison",
        description: "While social comparison can be motivating, it's important to prevent users from becoming overly focused on comparisons, which could lead to discouragement or unhealthy behaviors."
      },
      {
        title: "Brand Challenge Balance",
        description: "While brand challenges can be engaging, it's important to balance them with non-branded challenges to maintain the platform's authenticity and avoid overwhelming users with commercial content."
      },
      {
        title: "User Data and Privacy",
        description: "With brand involvement, there's a need for clear communication about how user data is shared (if at all) with partnering brands, ensuring transparency and maintaining user trust."
      },
      {
        title: "Leaderboard Design",
        description: "Leaderboards must be carefully designed to motivate rather than discourage users. Multiple categories and filtering options help ensure users can find relevant comparisons at their level."
      }
    ],
    learnMoreLink: "https://www.strava.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-87Xhf9LLagttPdpYAIq5aOxZlgF6z4.png",
    overviewImageAlt: "Strava group challenge interface showing leaderboard and progress",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxPBlO7gmR7c2CLxE7pYeRj965mn5s.png",
    whyItWorksImageAlt: "Strava challenge details showing member participation and group progress",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-I0zBMBlT3VPjk0YipJQXdgsHP2TzSs.png",
        alt: "Strava club challenges and group activities interface"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxPBlO7gmR7c2CLxE7pYeRj965mn5s.png",
        alt: "Strava leaderboard showing rankings for different categories"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-87Xhf9LLagttPdpYAIq5aOxZlgF6z4.png",
        alt: "Strava brand challenge interface showing Nike's 'Run 50K in June' challenge"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxPBlO7gmR7c2CLxE7pYeRj965mn5s.png",
        alt: "Brooks Running brand page on Strava showcasing multiple seasonal challenges"
      }
    ]
  },
  {
    id: "strava-influencer-integration",
    category: "Community",
    title: "Strava: Influencer Integration",
    subtitle: "Leveraging professional athletes and influencers to drive engagement",
    description: "Enhance user motivation and engagement through authentic interactions with professional athletes and influencers.",
    whyItWorks: [
      {
        title: "Authentic Athlete Interactions",
        description: "When a professional athlete gives kudos to a regular user's activity, it creates a genuine connection that validates their efforts. This authenticity stems from the transparent nature of the platform - everyone's data is real and verifiable."
      },
      {
        title: "Attainable Aspirations",
        description: "Unlike other social platforms where celebrity interactions feel artificial, Strava shows raw, unfiltered training data from professional athletes. Users can directly compare their local running times to Tour de France riders or marathon training to Olympic athletes, creating what psychologists call 'attainable aspirations.'"
      },
      {
        title: "Growth Mindset Through Athletes",
        description: "Following professional athletes' training routines and seeing their dedication creates what psychologists call a 'growth mindset' - the belief that you too can get better with effort. This is especially powerful when users see the day-to-day work behind exceptional performances."
      },
      {
        title: "Social Proof and Motivation",
        description: "Seeing professional athletes and influencers use the platform provides social proof of its value. Their presence can motivate users to push harder and stay consistent with their training."
      },
      {
        title: "Community Building",
        description: "Influencers can create and lead challenges, fostering a sense of community among their followers and other Strava users. This can lead to increased engagement and retention on the platform."
      }
    ],
    considerations: [
      {
        title: "Maintaining Authenticity",
        description: "It's crucial to ensure that influencer interactions remain genuine and not overly commercialized. The value comes from real, unfiltered data and interactions."
      },
      {
        title: "Privacy and Control",
        description: "Users should have control over their interactions with influencers and professional athletes, including the ability to limit visibility of their own activities."
      },
      {
        title: "Balanced Exposure",
        description: "While influencer content can be motivating, it's important not to overshadow regular users' content and achievements. A balance must be struck to maintain the community aspect."
      },
      {
        title: "Diverse Representation",
        description: "Ensure a diverse range of influencers and professional athletes across different sports, skill levels, and demographics to appeal to a broad user base."
      }
    ],
    learnMoreLink: "https://www.strava.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxVCoFdX3XsSSwbrGR0sFMsqotyXNA.png",
    overviewImageAlt: "Strava influencer profile showing interaction with regular users",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-MtJCoXDgQUdduflZw7g4twzEfPmcVg.png",
    whyItWorksImageAlt: "Professional athlete giving kudos to a regular user's activity",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxVCoFdX3XsSSwbrGR0sFMsqotyXNA.png",
        alt: "Strava influencer profile showcasing recent activities and follower interactions"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-MtJCoXDgQUdduflZw7g4twzEfPmcVg.png",
        alt: "Comparison view of a professional athlete's training data alongside a regular user's activity"
      }
    ]
  },
  {
    id: "strava-brand-challenges",
    category: "Community",
    title: "Strava: Brand Challenges",
    subtitle: "Engaging users through branded fitness challenges",
    description: "Increase user engagement and brand exposure through integrated fitness challenges.",
    whyItWorks: [
      {
        title: "Seamless Brand Integration",
        description: "Strava integrates brand challenges seamlessly, turning regular workouts into exciting events. Users participate in meaningful activities rather than seeing traditional ads, creating a more engaging experience with brands."
      },
      {
        title: "Natural Brand Exposure",
        description: "Brand challenges feel natural and authentic. Completing a challenge and earning a badge feels like a real achievement, similar to earning a medal in a race, rather than being marketed to directly."
      },
      {
        title: "Organic Brand Promotion",
        description: "When users share their achievements from brand challenges, they naturally spread the word about brands without feeling like they're advertising. This organic promotion is more effective and authentic than traditional marketing methods."
      },
      {
        title: "Continuous Engagement",
        description: "Smart brands create a series of challenges that keep people coming back, such as seasonal challenges for different types of activities. This approach provides ongoing reasons for users to engage with the platform and invite more friends, growing the community."
      },
      {
        title: "Motivation Boost",
        description: "Brand challenges often come with rewards or recognition, providing additional motivation for users to push themselves and achieve their fitness goals."
      }
    ],
    considerations: [
      {
        title: "Balance with Non-Branded Content",
        description: "While brand challenges can be engaging, it's important to balance them with non-branded challenges to maintain the platform's authenticity and avoid overwhelming users with commercial content."
      },
      {
        title: "Relevance and Value",
        description: "Brand challenges should provide genuine value to users and be relevant to their fitness goals. Challenges that feel forced or purely promotional may turn users off."
      },
      {
        title: "Transparency",
        description: "Be clear about the branded nature of challenges and any data sharing involved. Maintaining user trust is crucial for the success of brand integrations."
      },
      {
        title: "Inclusive Design",
        description: "Ensure that brand challenges cater to a wide range of fitness levels and activity types to maximize participation and positive brand association."
      }
    ],
    learnMoreLink: "https://www.strava.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-87Xhf9LLagttPdpYAIq5aOxZlgF6z4.png",
    overviewImageAlt: "Strava brand challenge interface showing Nike's 'Run 50K in June' challenge",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxPBlO7gmR7c2CLxE7pYeRj965mn5s.png",
    whyItWorksImageAlt: "Brooks Running brand page on Strava showcasing multiple seasonal challenges",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-87Xhf9LLagttPdpYAIq5aOxZlgF6z4.png",
        alt: "User participating in a Strava brand challenge"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxPBlO7gmR7c2CLxE7pYeRj965mn5s.png",
        alt: "Strava brand challenge completion badge and social sharing option"
      }
    ]
  },
  {
    id: "strava-leaderboards",
    category: "Community",
    title: "Strava: Leaderboards",
    subtitle: "Fostering healthy competition through multi-faceted leaderboards",
    description: "Drive engagement and motivation through strategically designed leaderboards and social comparison.",
    whyItWorks: [
      {
        title: "Social Comparison and Proof",
        description: "Leaderboards tap into Social Comparison Theory, allowing users to assess their abilities by comparing themselves to others. Seeing their name move up the leaderboard creates social proof of their efforts, reinforcing their commitment to the activity and the platform."
      },
      {
        title: "Layered Leaderboards",
        description: "Strava's smart approach to leaderboards shows rankings among various groups (age, gender, weight, specific clubs, followed users), ensuring almost everyone can find a meaningful competition and experience success."
      },
      {
        title: "Motivation Through Visibility",
        description: "The visibility of performance on leaderboards creates social facilitation, where users tend to perform better when they know others are watching. This often leads to increased effort and consistency in individual exercises."
      },
      {
        title: "Goal Setting",
        description: "Leaderboards provide clear, quantifiable goals for users to aim for, whether it's improving their ranking or achieving a specific time or distance benchmark."
      },
      {
        title: "Community Building",
        description: "Leaderboards foster a sense of community by allowing users to see and interact with others who have similar performance levels or goals, potentially leading to new connections and training partnerships."
      }
    ],
    considerations: [
      {
        title: "Avoiding Discouragement",
        description: "For less competitive or newer users, constantly seeing themselves at the bottom of leaderboards can be discouraging. It's crucial to provide alternative ways of measuring progress and success."
      },
      {
        title: "Fair Play",
        description: "Implement robust systems to detect and prevent cheating or data manipulation that could unfairly impact leaderboard positions."
      },
      {
        title: "Privacy Controls",
        description: "Offer granular privacy settings that allow users to control their visibility on leaderboards and who can see their performance data."
      },
      {
        title: "Inclusive Design",
        description: "Ensure leaderboards cater to a wide range of activities, skill levels, and user goals to maximize engagement across the entire user base."
      },
      {
        title: "Balanced Focus",
        description: "While leaderboards can drive engagement, ensure they don't overshadow the primary goal of personal health and fitness improvement. Emphasize personal bests alongside comparative rankings."
      }
    ],
    learnMoreLink: "https://www.strava.com",
    overviewImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxPBlO7gmR7c2CLxE7pYeRj965mn5s.png",
    overviewImageAlt: "Strava leaderboard showing rankings for different categories",
    whyItWorksImageUrl: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-87Xhf9LLagttPdpYAIq5aOxZlgF6z4.png",
    whyItWorksImageAlt: "Strava segment leaderboard with filters for age and weight categories",
    additionalImages: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-cxPBlO7gmR7c2CLxE7pYeRj965mn5s.png",
        alt: "Strava global challenge leaderboard"
      },
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-87Xhf9LLagttPdpYAIq5aOxZlgF6z4.png",
        alt: "Strava club leaderboard showing member rankings"
      }
    ]
  }
];
