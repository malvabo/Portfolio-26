import { ArrowRight, Linkedin } from 'lucide-react'

export default function AboutAuthor() {
  return (
    <div className="min-h-screen bg-[var(--color-linen-white)]">
      <div className="ease-container py-[56px]">
        <div className="rounded-[14px] border border-[var(--color-hairline-gray)] bg-[var(--color-linen-white)] p-[42px]">
          <span className="ease-pill ease-pill-section mb-[21px]">About the library</span>
          <h1 className="mb-[28px] text-[56px] font-light leading-none text-[var(--color-forest-ink)]">HealthTech Patterns</h1>
          
          <div className="max-w-[760px]">
            <p className="mb-[35px] text-[18px] leading-[1.3] text-[var(--color-charcoal)]">
              Exploring innovative digital health solutions to improve user engagement and well-being.
            </p>

            <div className="space-y-[21px] text-[18px] leading-[1.3] text-[var(--color-charcoal)]">
              <p className="text-[var(--color-charcoal)]">
                Digital health technology is fundamentally changing how we track, manage, and improve our health and wellness. 
                We are only just starting to see how these changes will manifest in our digital products, across services and 
                experiences, and within our healthcare organizations.
              </p>

              <p className="text-[var(--color-charcoal)]">
                By studying and documenting successful patterns from leading digital health products, we can better understand 
                what works and why. This knowledge helps us create more effective, engaging, and human-centered health technology.
              </p>

              <p className="text-[var(--color-charcoal)]">
                Each pattern is carefully analyzed to understand the psychological principles behind its effectiveness, 
                implementation considerations, and real-world impact. Our goal is to provide practical insights that 
                can be applied to create better digital health experiences.
              </p>

              <div className="mt-[42px] rounded-[14px] bg-[var(--color-mint-veil)] p-[21px]">
                <span className="ease-pill ease-pill-quiet mb-[14px]">Author</span>
                <h2 className="mb-[14px] text-[40px] font-light leading-[1.15] text-[var(--color-forest-ink)]">Curated by Maria Borysova</h2>
                <p className="text-[var(--color-charcoal)]">
                  This collection is curated by Maria Borysova, a product designer and design studio founder focused on 
                  creating innovative healthcare products and driving revenue growth through effective user engagement strategies.
                </p>
                <div className="mt-[21px]">
                  <a 
                    href="https://www.linkedin.com/in/maria-borysova/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ease-button"
                  >
                    <Linkedin className="h-4 w-4" />
                    <span>Connect on LinkedIn</span>
                    <ArrowRight className="h-4 w-4" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
