import PatternCard from './components/pattern-card'
import Link from 'next/link'
import { getAllPatterns } from '../data/patterns'
import { Trophy, Users, Brain, Watch } from 'lucide-react'

const categories = {
  'Gamification': {
    icon: Trophy,
    label: 'Motivation loops',
    description: 'Streaks, badges, goals, and rewards that make healthy routines feel visible and worth returning to.',
    patterns: ['duolingo-streaks-gamification', 'duolingo-achievement-badges'],
  },
  'Community': {
    icon: Users,
    label: 'Social scaffolding',
    description: 'Shared challenges and peer comparison patterns that turn solitary behavior change into a supported practice.',
    patterns: ['strava-community-features', 'strava-group-challenges'],
  },
  'AI Companion': {
    icon: Brain,
    label: 'Always-on support',
    description: 'Conversational and avatar patterns for sensitive, continuous engagement in emotional health contexts.',
    patterns: ['replika-ai-avatar-gamification', 'replika-ai-mental-health-chatbot'],
  },
  'Wearables': {
    icon: Watch,
    label: 'Data into care',
    description: 'Progressive disclosure patterns that translate biometric complexity into calm, actionable guidance.',
    patterns: ['whoop-recovery-metrics'],
  },
}

export default function Home() {
  const patterns = getAllPatterns()

  return (
    <div className="ease-container py-12">
      <section className="mb-16 grid overflow-hidden rounded-[14px] border border-[var(--color-hairline-gray)] lg:grid-cols-[1.05fr_0.95fr]">
        <div className="bg-[var(--color-sage-wash)] p-8 md:p-12">
          <span className="ease-pill ease-pill-quiet mb-6">Engagement library</span>
          <h1 className="ease-display max-w-[680px] text-[44px] leading-[1.02] md:text-[56px]">
            Healthcare patterns for calmer, stickier care journeys
          </h1>
          <p className="mt-6 max-w-[600px] text-[18px] leading-[1.45] text-[var(--color-charcoal)]">
            A curated library of behavior design patterns from health, fitness, and wellbeing products. Use it to study how trust, motivation, and repeat engagement are built without adding noise.
          </p>
        </div>
        <div className="bg-[var(--color-mist-blue)] p-8 md:p-12">
          <div className="grid gap-4">
            {Object.entries(categories).map(([category, { label, patterns: patternIds }]) => (
              <a
                key={category}
                href={`#${category.toLowerCase().replace(' ', '-')}`}
                className="rounded-[14px] bg-[var(--color-linen-white)] p-5 text-[var(--color-forest-ink)] transition-colors hover:bg-[var(--color-soft-card)]"
              >
                <span className="text-[13px] leading-[1.5] text-[var(--color-charcoal)]">{label}</span>
                <div className="mt-2 flex items-end justify-between gap-4">
                  <span className="ease-ui-heading text-[28px] leading-[1.1]">{category}</span>
                  <span className="text-[12px] leading-[1.5] text-[var(--color-charcoal)]">{patternIds.length} patterns</span>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>
        
      {Object.entries(categories).map(([category, { icon: CategoryIcon, label, description, patterns: patternIds }]) => (
        <section key={category} className="mb-16" id={category.toLowerCase().replace(' ', '-')}>
          <div className="mb-8 max-w-[760px]">
            <span className="ease-pill ease-pill-section mb-4">{label}</span>
            <div className="flex items-center gap-4">
              <span className="ease-check">
                <CategoryIcon className="h-4 w-4" />
              </span>
              <h2 className="ease-display text-[40px] leading-[1.12]">{category}</h2>
            </div>
            <p className="mt-4 max-w-[680px] text-[18px] leading-[1.45] text-[var(--color-charcoal)]">{description}</p>
          </div>
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
            {patternIds.map(id => {
              const pattern = patterns.find(p => p.id === id)
              if (!pattern) return null
              return (
                <Link key={pattern.id} href={`/patterns/${pattern.id}`} className="block">
                  <PatternCard 
                    company={pattern.title} 
                    description={pattern.description}
                  />
                </Link>
              )
            })}
          </div>
        </section>
      ))}
    </div>
  )
}
