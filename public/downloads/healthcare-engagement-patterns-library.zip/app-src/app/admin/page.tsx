'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import RichTextEditor from '../components/rich-text-editor'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'

interface WhyItWorksPoint {
  title: string
  description: string
}

interface Consideration {
  title: string
  description: string
}

export default function AdminPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    title: '',
    subtitle: '',
    description: '',
    category: '',
    overview: {
      text: '',
      image: {
        url: '',
        alt: ''
      }
    },
    whyItWorks: {
      points: [{ title: '', description: '' }] as WhyItWorksPoint[],
      image: {
        url: '',
        alt: ''
      }
    },
    considerations: [{ title: '', description: '' }] as Consideration[],
    learnMoreLink: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch('/api/patterns', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
      })
      
      if (!response.ok) {
        throw new Error('Failed to save pattern')
      }

      router.push('/')
    } catch (error) {
      console.error('Error saving pattern:', error)
      alert('Failed to save pattern')
    } finally {
      setLoading(false)
    }
  }

  const addWhyItWorksPoint = () => {
    setFormData(prev => ({
      ...prev,
      whyItWorks: {
        ...prev.whyItWorks,
        points: [...prev.whyItWorks.points, { title: '', description: '' }]
      }
    }))
  }

  const addConsideration = () => {
    setFormData(prev => ({
      ...prev,
      considerations: [...prev.considerations, { title: '', description: '' }]
    }))
  }

  return (
    <div className="max-w-6xl mx-auto px-8 py-12">
      <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to all patterns
      </Link>

      <h1 className="text-3xl font-bold mb-8 font-manrope">Create New Pattern</h1>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-4">
          <div>
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
              required
            />
          </div>

          <div>
            <Label htmlFor="subtitle">Subtitle</Label>
            <Input
              id="subtitle"
              value={formData.subtitle}
              onChange={e => setFormData(prev => ({ ...prev, subtitle: e.target.value }))}
              required
            />
          </div>

          <div>
            <Label htmlFor="category">Category</Label>
            <Input
              id="category"
              value={formData.category}
              onChange={e => setFormData(prev => ({ ...prev, category: e.target.value }))}
              required
            />
          </div>

          <div>
            <Label htmlFor="overview">Overview</Label>
            <RichTextEditor
              value={formData.overview.text}
              onChange={value => setFormData(prev => ({
                ...prev,
                overview: { ...prev.overview, text: value }
              }))}
            />
          </div>

          <div>
            <Label>Overview Image</Label>
            <Input
              placeholder="Image URL"
              value={formData.overview.image.url}
              onChange={e => setFormData(prev => ({
                ...prev,
                overview: {
                  ...prev.overview,
                  image: { ...prev.overview.image, url: e.target.value }
                }
              }))}
            />
            <Input
              placeholder="Image Alt Text"
              className="mt-2"
              value={formData.overview.image.alt}
              onChange={e => setFormData(prev => ({
                ...prev,
                overview: {
                  ...prev.overview,
                  image: { ...prev.overview.image, alt: e.target.value }
                }
              }))}
            />
          </div>

          <div>
            <Label>Why it Works</Label>
            {formData.whyItWorks.points.map((point, index) => (
              <div key={index} className="space-y-2 mt-4">
                <Input
                  placeholder="Point Title"
                  value={point.title}
                  onChange={e => {
                    const newPoints = [...formData.whyItWorks.points]
                    newPoints[index].title = e.target.value
                    setFormData(prev => ({
                      ...prev,
                      whyItWorks: { ...prev.whyItWorks, points: newPoints }
                    }))
                  }}
                />
                <RichTextEditor
                  value={point.description}
                  onChange={value => {
                    const newPoints = [...formData.whyItWorks.points]
                    newPoints[index].description = value
                    setFormData(prev => ({
                      ...prev,
                      whyItWorks: { ...prev.whyItWorks, points: newPoints }
                    }))
                  }}
                />
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              onClick={addWhyItWorksPoint}
              className="mt-4"
            >
              Add Point
            </Button>
          </div>

          <div>
            <Label>Considerations</Label>
            {formData.considerations.map((consideration, index) => (
              <div key={index} className="space-y-2 mt-4">
                <Input
                  placeholder="Consideration Title"
                  value={consideration.title}
                  onChange={e => {
                    const newConsiderations = [...formData.considerations]
                    newConsiderations[index].title = e.target.value
                    setFormData(prev => ({
                      ...prev,
                      considerations: newConsiderations
                    }))
                  }}
                />
                <RichTextEditor
                  value={consideration.description}
                  onChange={value => {
                    const newConsiderations = [...formData.considerations]
                    newConsiderations[index].description = value
                    setFormData(prev => ({
                      ...prev,
                      considerations: newConsiderations
                    }))
                  }}
                />
              </div>
            ))}
            <Button
              type="button"
              variant="outline"
              onClick={addConsideration}
              className="mt-4"
            >
              Add Consideration
            </Button>
          </div>

          <div>
            <Label htmlFor="learnMoreLink">Learn More Link</Label>
            <Input
              id="learnMoreLink"
              value={formData.learnMoreLink}
              onChange={e => setFormData(prev => ({ ...prev, learnMoreLink: e.target.value }))}
              required
            />
          </div>
        </div>

        <Button type="submit" disabled={loading}>
          {loading ? 'Saving...' : 'Save Pattern'}
        </Button>
      </form>
    </div>
  )
}

