import './globals.css'
import Navigation from './components/navigation'
import LayoutContent from './components/LayoutContent'

export const metadata = {
  title: 'Healthcare Engagement Patterns',
  description: 'A quiet library of behavior design patterns for healthcare and wellbeing products',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[var(--color-linen-white)]">
        <Navigation />
        <LayoutContent>{children}</LayoutContent>
      </body>
    </html>
  )
}
