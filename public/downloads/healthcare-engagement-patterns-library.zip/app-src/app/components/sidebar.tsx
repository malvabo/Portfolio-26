import Link from 'next/link'
import { getAllPatterns } from '../../data/patterns'
import { Brain, Users, Trophy, Watch } from 'lucide-react'

const categories = {
  'Gamification': { icon: Trophy, patterns: ['duolingo-streaks-gamification', 'duolingo-achievement-badges'] },
  'Community': { icon: Users, patterns: ['strava-community-features', 'strava-group-challenges'] },
  'AI Companion': { icon: Brain, patterns: ['replika-ai-avatar-gamification', 'replika-ai-mental-health-chatbot'] },
  'Wearables': { icon: Watch, patterns: ['whoop-recovery-metrics'] },
}

export default function Sidebar() {
  const patterns = getAllPatterns()

  return (
    <aside className="fixed left-0 top-16 hidden h-[calc(100vh-4rem)] w-72 overflow-y-auto border-r border-[rgba(15,62,23,0.08)] bg-[var(--color-linen-white)] lg:block">
      <nav className="px-6 py-7">
        <span className="ease-pill ease-pill-index mb-7">Care patterns</span>
        {Object.entries(categories).map(([category, { icon: CategoryIcon, patterns: patternIds }]) => (
          <div key={category} className="mb-8 last:mb-0">
            <h3 className="ease-ui-heading mb-3 flex min-h-8 items-center gap-2 text-[15px] leading-[1.35]">
              <CategoryIcon className="h-4 w-4 shrink-0 text-[var(--color-forest-ink)]" />
              {category}
            </h3>
            <ul className="space-y-1.5">
              {patternIds.map(id => {
                const pattern = patterns.find(p => p.id === id)
                if (!pattern) return null
                
                const patternName = pattern.title.split(': ')[1] || pattern.title
                
                return (
                  <li key={id}>
                    <Link 
                      href={`/patterns/${id}`}
                      className="block rounded-[7px] border border-transparent px-3 py-2.5 text-[14px] leading-[1.4] text-[color:rgba(34,34,34,0.84)] transition-colors duration-200 hover:border-[rgba(15,62,23,0.06)] hover:bg-[var(--color-soft-card)] hover:text-[var(--color-forest-ink)]"
                      title={pattern.title}
                    >
                      <span className="block truncate">{patternName}</span>
                    </Link>
                  </li>
                )
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  )
}
