'use client'

interface RichTextEditorProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
}

export default function RichTextEditor({ value, onChange, placeholder }: RichTextEditorProps) {
  return (
    <textarea
      value={value}
      onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder}
      className="min-h-[150px] w-full rounded-[14px] border border-[var(--color-hairline-gray)] bg-[var(--color-linen-white)] p-[14px] text-sm leading-[1.5] text-[var(--color-charcoal)] outline-none focus:border-[var(--color-forest-ink)]"
    />
  )
}
