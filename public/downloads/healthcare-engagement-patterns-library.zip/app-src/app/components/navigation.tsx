'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function Navigation() {
  const pathname = usePathname()
  
  return (
    <header className="fixed left-0 right-0 top-0 z-50 border-b border-[rgba(15,62,23,0.08)] bg-[var(--color-linen-white)]">
      <div className="ease-container">
        <div className="flex h-16 items-center justify-between">
          <div className="min-w-0 flex items-center">
            <Link href="/" className="flex min-h-9 items-center gap-3 text-[var(--color-forest-ink)]">
              <span className="h-3 w-3 shrink-0 rounded-full bg-[var(--color-forest-ink)]" />
              <span className="truncate text-[15px] font-normal leading-[1.35] text-[var(--color-forest-ink)]">Healthcare Engagement Patterns</span>
            </Link>
          </div>
          
          <nav className="hidden items-center gap-1 md:flex">
            <a 
              href="https://techmattersstudio.com/projects"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-9 items-center rounded-[7px] px-3 text-[14px] font-normal leading-[1.35] text-[color:rgba(34,34,34,0.82)] transition-colors hover:bg-[var(--color-soft-card)] hover:text-[var(--color-forest-ink)]"
            >
              Cases
            </a>
            <a 
              href="https://techmattersstudio.com/services"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-9 items-center rounded-[7px] px-3 text-[14px] font-normal leading-[1.35] text-[color:rgba(34,34,34,0.82)] transition-colors hover:bg-[var(--color-soft-card)] hover:text-[var(--color-forest-ink)]"
            >
              Services
            </a>
            <a 
              href="https://techmattersstudio.com/blog2"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-9 items-center rounded-[7px] px-3 text-[14px] font-normal leading-[1.35] text-[color:rgba(34,34,34,0.82)] transition-colors hover:bg-[var(--color-soft-card)] hover:text-[var(--color-forest-ink)]"
            >
              Blog
            </a>
            <Link 
              href="/"
              className={`inline-flex h-9 items-center rounded-[7px] px-3 text-[14px] font-normal leading-[1.35] transition-colors hover:bg-[var(--color-soft-card)] hover:text-[var(--color-forest-ink)] ${
                pathname === '/' ? 'bg-[var(--color-soft-card)] text-[var(--color-forest-ink)]' : 'text-[color:rgba(34,34,34,0.82)]'
              }`}
            >
              Library
            </Link>
            <Link 
              href="/about-author"
              className={`inline-flex h-9 items-center rounded-[7px] px-3 text-[14px] font-normal leading-[1.35] transition-colors hover:bg-[var(--color-soft-card)] hover:text-[var(--color-forest-ink)] ${
                pathname === '/about-author' ? 'bg-[var(--color-soft-card)] text-[var(--color-forest-ink)]' : 'text-[color:rgba(34,34,34,0.82)]'
              }`}
            >
              About
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}
