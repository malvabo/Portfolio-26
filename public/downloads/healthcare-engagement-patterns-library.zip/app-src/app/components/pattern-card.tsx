import { ArrowRight } from 'lucide-react'

interface PatternCardProps {
  company: string
  description: string
}

export default function PatternCard({ company, description }: PatternCardProps) {
  const patternName = company.split(':')[1]?.trim() || company
  const source = company.includes(':') ? company.split(':')[0] : 'Pattern'

  return (
    <div className="ease-card group flex min-h-[176px] flex-col overflow-hidden transition-colors duration-200 hover:bg-[var(--color-linen-white)]">
      <div className="flex h-full flex-col p-6">
        <div className="mb-4 flex items-center justify-between gap-4">
          <span className="ease-pill ease-pill-source text-[12px]">{source}</span>
          <ArrowRight className="h-4 w-4 text-[var(--color-forest-ink)] transition-transform group-hover:translate-x-1" />
        </div>
        <div className="flex-grow">
          <h3 className="ease-ui-heading mb-3 line-clamp-2 text-[22px] leading-[1.22]">
            {patternName}
          </h3>
          <p className="line-clamp-3 text-[15px] leading-[1.45] text-[var(--color-charcoal)]">{description}</p>
        </div>
        <div className="pt-4 text-[14px] font-normal text-[var(--color-forest-ink)]">
          View pattern
        </div>
      </div>
    </div>
  )
}
