'use client'

import { usePathname } from 'next/navigation'
import Sidebar from './sidebar'

interface LayoutContentProps {
  children: React.ReactNode
}

export default function LayoutContent({ children }: LayoutContentProps) {
  const pathname = usePathname()
  const isPatternPage = pathname.startsWith('/patterns/')

  return (
    <div className="flex">
      {!isPatternPage && <Sidebar />}
      <main className={`mt-16 flex-1 ${isPatternPage ? 'w-full' : 'lg:ml-72'}`}>{children}</main>
    </div>
  )
}
