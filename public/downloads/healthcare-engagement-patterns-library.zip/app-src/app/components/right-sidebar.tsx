import Link from 'next/link'
import { getAllPatterns } from '../../data/patterns'
import { Brain, Users, Trophy, Watch } from 'lucide-react'

const categories = {
  'Gamification': { icon: Trophy, patterns: ['duolingo-streaks-gamification', 'duolingo-achievement-badges'] },
  'Community': { icon: Users, patterns: ['strava-community-features', 'strava-group-challenges'] },
  'AI Companion': { icon: Brain, patterns: ['replika-ai-avatar-gamification', 'replika-ai-mental-health-chatbot'] },
  'Wearables': { icon: Watch, patterns: ['whoop-recovery-metrics'] },
}

export default function RightSidebar() {
  return (
    <aside className="fixed right-0 top-16 h-[calc(100vh-4rem)] w-64 overflow-y-auto border-l border-[rgba(15,62,23,0.08)] bg-[var(--color-linen-white)]">
      <nav className="px-5 py-7">
        <h2 className="ease-ui-heading mb-4 text-[15px] leading-[1.35]">Chapters</h2>
        {Object.entries(categories).map(([category, { icon: CategoryIcon }]) => (
          <Link 
            key={category} 
            href={`#${category.toLowerCase().replace(' ', '-')}`}
            className="flex min-h-9 items-center rounded-[7px] px-3 py-2 text-[14px] leading-[1.4] text-[color:rgba(34,34,34,0.84)] transition-colors duration-200 hover:bg-[var(--color-soft-card)] hover:text-[var(--color-forest-ink)]"
          >
            <CategoryIcon className="mr-2 h-4 w-4 text-[var(--color-forest-ink)]" />
            {category}
          </Link>
        ))}
      </nav>
    </aside>
  )
}
