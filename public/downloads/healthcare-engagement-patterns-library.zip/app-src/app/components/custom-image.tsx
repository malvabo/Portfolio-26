'use client'

import Image, { ImageProps } from 'next/image'
import { useState } from 'react'
import { ImageOff } from 'lucide-react'

interface CustomImageProps extends Omit<ImageProps, 'onError'> {
  fallbackSrc?: string
}

export default function CustomImage({ src, alt, fallbackSrc = '/placeholder.svg', className, ...rest }: CustomImageProps) {
  const [imgSrc, setImgSrc] = useState(src)
  const [hasError, setHasError] = useState(false)

  if (hasError) {
    return (
      <div
        className={`flex min-h-[320px] w-full flex-col items-center justify-center gap-3 rounded-[14px] border border-[rgba(15,62,23,0.04)] bg-[var(--color-soft-card)] p-8 text-center text-[var(--color-forest-ink)] ${className || ''}`}
        role="img"
        aria-label={alt}
      >
        <span className="ease-check">
          <ImageOff className="h-4 w-4" />
        </span>
        <span className="max-w-[520px] text-[15px] leading-[1.5] text-[var(--color-charcoal)]">
          Image unavailable: {alt}
        </span>
      </div>
    )
  }

  return (
    <Image
      {...rest}
      src={imgSrc || "/placeholder.svg"}
      alt={alt}
      className={className}
      onError={() => {
        if (fallbackSrc && fallbackSrc !== imgSrc && fallbackSrc !== '/placeholder.svg') {
          setImgSrc(fallbackSrc)
          return
        }

        setHasError(true)
      }}
    />
  )
}
