import { NextResponse } from 'next/server'
import { addUserPattern } from '@/data/patterns'

export async function POST(request: Request) {
  try {
    const { rawText } = await request.json()
    
    if (!rawText) {
      return NextResponse.json(
        { error: 'Raw text is required' },
        { status: 400 }
      )
    }

    // Here you would implement the logic to parse the raw text
    // and extract the necessary information to create a pattern
    // For now, we'll just create a simple pattern with the raw text as the title

    const pattern = {
      title: rawText.slice(0, 100), // Use the first 100 characters as the title
      subtitle: '',
      description: rawText,
      category: 'Uncategorized',
      overview: rawText,
      overviewImageUrl: '',
      overviewImageAlt: '',
      whyItWorks: [],
      whyItWorksImageUrl: '',
      whyItWorksImageAlt: '',
      considerations: [],
      learnMoreLink: '',
      additionalImages: []
    }

    const newPattern = addUserPattern(pattern)

    return NextResponse.json({ success: true, pattern: newPattern })
  } catch (error) {
    console.error('Error saving raw pattern:', error)
    return NextResponse.json(
      { error: 'Failed to save pattern', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
