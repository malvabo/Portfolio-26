import { NextResponse } from 'next/server'
import { Pattern } from '@/types/patterns'
import { addUserPattern, updateUserPattern, deleteUserPattern, getPatternById, getAllPatterns } from '@/data/patterns'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get('id')

  if (id) {
    const pattern = getPatternById(id)
    if (pattern) {
      return NextResponse.json(pattern)
    } else {
      return NextResponse.json({ error: 'Pattern not found' }, { status: 404 })
    }
  } else {
    const patterns = getAllPatterns()
    return NextResponse.json(patterns)
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    
    if (!data.title) {
      return NextResponse.json(
        { error: 'Title is required' },
        { status: 400 }
      )
    }

    const pattern: Omit<Pattern, 'id'> = {
      title: data.title,
      subtitle: data.subtitle || '',
      description: data.description || '',
      category: data.category || '',
      overview: data.overview?.text || '',
      overviewImageUrl: data.overview?.image?.url || '',
      overviewImageAlt: data.overview?.image?.alt || '',
      whyItWorks: data.whyItWorks?.points || [],
      whyItWorksImageUrl: data.whyItWorks?.image?.url || '',
      whyItWorksImageAlt: data.whyItWorks?.image?.alt || '',
      considerations: data.considerations || [],
      learnMoreLink: data.learnMoreLink || '',
      additionalImages: []
    }

    const newPattern = addUserPattern(pattern)

    return NextResponse.json({ success: true, pattern: newPattern })
  } catch (error) {
    console.error('Error saving pattern:', error)
    return NextResponse.json(
      { error: 'Failed to save pattern', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

export async function PUT(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Pattern ID is required' }, { status: 400 })
    }

    const data = await request.json()
    const updatedPattern = updateUserPattern(id, data)

    if (updatedPattern) {
      return NextResponse.json({ success: true, pattern: updatedPattern })
    } else {
      return NextResponse.json({ error: 'Pattern not found' }, { status: 404 })
    }
  } catch (error) {
    console.error('Error updating pattern:', error)
    return NextResponse.json(
      { error: 'Failed to update pattern', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'Pattern ID is required' }, { status: 400 })
    }

    const deleted = deleteUserPattern(id)

    if (deleted) {
      return NextResponse.json({ success: true, message: 'Pattern deleted successfully' })
    } else {
      return NextResponse.json({ error: 'Pattern not found' }, { status: 404 })
    }
  } catch (error) {
    console.error('Error deleting pattern:', error)
    return NextResponse.json(
      { error: 'Failed to delete pattern', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
