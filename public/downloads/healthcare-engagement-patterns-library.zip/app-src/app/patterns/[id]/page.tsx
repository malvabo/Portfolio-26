import Link from "next/link"
import { ArrowLeft, ArrowRight, Check } from "lucide-react"
import { getPatternById, getAllPatterns } from "../../../data/patterns"
import { notFound } from "next/navigation"
import CustomImage from "../../components/custom-image"

export default function PatternPage({ params }: { params: { id: string } }) {
  const pattern = getPatternById(params.id)
  const allPatterns = getAllPatterns()

  if (!pattern) {
    notFound()
  }

  const patternName = pattern.title.split(":")[1]?.trim() || pattern.title
  const sourceName = pattern.title.includes(":") ? pattern.title.split(":")[0] : pattern.category
  const relatedPatterns = allPatterns.filter((relatedPattern) => relatedPattern.id !== pattern.id).slice(0, 3)

  return (
    <div className="min-h-screen bg-[var(--color-linen-white)]">
      <section className="border-b border-[var(--color-hairline-gray)] bg-[var(--color-linen-white)]">
        <div className="ease-container py-12 md:py-16">
          <div className="mb-10 flex flex-wrap items-center gap-3 text-[14px] text-[var(--color-forest-ink)]">
            <Link href="/" className="flex items-center rounded-[7px] px-3 py-2 transition-colors hover:bg-white">
              <ArrowLeft className="mr-2 h-4 w-4" />
              All patterns
            </Link>
            <span className="text-[color:rgba(34,34,34,0.45)]">/</span>
            <span className="text-[color:rgba(34,34,34,0.78)]">{patternName}</span>
          </div>

          <div className="grid gap-10 lg:grid-cols-[minmax(0,0.95fr)_minmax(320px,0.5fr)] lg:items-start">
            <div>
              <span className="ease-pill ease-pill-quiet mb-6">{sourceName}</span>
              <h1 className="ease-display max-w-[820px] text-[44px] leading-[1.04] md:text-[68px]">{patternName}</h1>
              <p className="mt-6 max-w-[760px] text-[21px] leading-[1.55] text-[color:rgba(15,62,23,0.9)] md:text-[22px]">{pattern.subtitle}</p>
            </div>
            <div className="ease-text-block p-6">
              <span className="ease-pill ease-pill-section mb-4">Pattern read</span>
              <p className="text-[17px] leading-[1.65] text-[var(--color-charcoal)]">{pattern.description}</p>
              <a href={pattern.learnMoreLink} target="_blank" rel="noopener noreferrer" className="ease-button mt-6">
                Source product
                <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      <div className="ease-container py-16 md:py-20">
        <div className="grid grid-cols-1 gap-14 lg:grid-cols-[minmax(0,0.72fr)_minmax(280px,0.28fr)]">
          <div className="lg:col-span-2">
            <section className="mb-20">
              <span className="ease-pill ease-pill-section mb-5">Why it works</span>
              <h2 className="ease-display mb-10 max-w-[780px] text-[42px] leading-[1.12] md:text-[54px]">The engagement mechanism</h2>
              <div className="grid gap-6">
              {pattern.whyItWorks.map((point, index) => (
                <div key={index} className="ease-text-block grid gap-5 p-6 md:grid-cols-[34px_1fr] md:p-7">
                  <span className="ease-check">
                    <Check className="h-4 w-4" />
                  </span>
                  <div>
                    <h3 className="ease-ui-heading mb-3 text-[23px] leading-[1.25]">{point.title}</h3>
                    <p className="max-w-[720px] text-[17px] leading-[1.68] text-[var(--color-charcoal)]">{point.description}</p>
                  </div>
                </div>
              ))}
              </div>
            </section>

            <section className="mb-20">
              <span className="ease-pill ease-pill-section mb-5">Interface evidence</span>
              <h2 className="ease-display mb-10 max-w-[780px] text-[42px] leading-[1.12] md:text-[54px]">Screens that carry the behavior</h2>
              <div className="grid gap-6">
              {pattern.additionalImages.map((image, index) => (
                <CustomImage
                  key={index}
                  src={image.url}
                  alt={image.alt}
                  width={800}
                  height={400}
                  className="w-full rounded-[14px] border border-[var(--color-hairline-gray)] bg-[var(--color-linen-white)] object-cover"
                />
              ))}
              </div>
            </section>

            <section>
              <span className="ease-pill ease-pill-section mb-5">Clinical caution</span>
              <h2 className="ease-display mb-10 max-w-[780px] text-[42px] leading-[1.12] md:text-[54px]">Design considerations</h2>
              <div className="grid gap-6">
              {pattern.considerations.map((consideration, index) => (
                <div key={index} className="ease-text-block p-6 md:p-7">
                  <h3 className="ease-ui-heading mb-3 text-[23px] leading-[1.25]">{consideration.title}</h3>
                  <p className="max-w-[720px] text-[17px] leading-[1.68] text-[var(--color-charcoal)]">{consideration.description}</p>
                </div>
              ))}
              </div>
            </section>
          </div>

          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-5">
              <div className="ease-text-block p-6">
                <span className="ease-pill ease-pill-quiet mb-4">Use when</span>
                <p className="text-[15px] leading-[1.65] text-[var(--color-charcoal)]">
                  You need to increase repeat engagement, trust, or behavior change in a health, fitness, or wellbeing product without making the experience feel loud.
                </p>
              </div>

              <div className="ease-card p-6">
                <span className="ease-pill ease-pill-section mb-4">Related patterns</span>
                <ul className="space-y-4">
                  {relatedPatterns.map((relatedPattern, index) => (
                    <li key={index}>
                      <Link href={`/patterns/${relatedPattern.id}`} className="group flex items-center justify-between gap-4 text-[15px] leading-[1.4] text-[var(--color-charcoal)] hover:text-[var(--color-forest-ink)]">
                        <span>{relatedPattern.title.split(":")[1]?.trim() || relatedPattern.title}</span>
                        <ArrowRight className="h-4 w-4 text-[var(--color-forest-ink)] transition-transform group-hover:translate-x-1" />
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
