import { redirect } from 'next/navigation'

export default function WhoopRedirect() {
  redirect('/patterns/whoop-recovery-metrics')
}
