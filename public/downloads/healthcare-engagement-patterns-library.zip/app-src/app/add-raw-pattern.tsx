'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'

export default function AddRawPattern() {
  const router = useRouter()
  const [rawText, setRawText] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await fetch('/api/patterns/raw', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ rawText })
      })
      
      if (!response.ok) {
        throw new Error('Failed to save pattern')
      }

      router.push('/')
    } catch (error) {
      console.error('Error saving pattern:', error)
      alert('Failed to save pattern')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to all patterns
      </Link>

      <h1 className="text-3xl font-bold mb-6">Add Raw Pattern Text</h1>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Textarea
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
            placeholder="Paste your raw pattern text here..."
            rows={20}
            className="w-full p-2 border rounded"
          />
        </div>

        <Button type="submit" disabled={loading}>
          {loading ? 'Saving...' : 'Save Pattern'}
        </Button>
      </form>
    </div>
  )
}

